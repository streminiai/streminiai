import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:math' as math;

/// A custom widget to create the glowing icon effect.
class GlowIconButton extends StatelessWidget {
  final IconData icon;
  final Color glowColor;
  final double size;
  final VoidCallback onTap;
  final double iconSize;

  const GlowIconButton({
    super.key,
    required this.icon,
    required this.glowColor,
    this.size = 50.0,
    required this.onTap,
    this.iconSize = 24.0,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.black,
          shape: BoxShape.circle,
          border: Border.all(
            color: glowColor.withOpacity(0.8),
            width: 2.5,
          ),
          boxShadow: [
            BoxShadow(
              color: glowColor.withOpacity(0.6),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: iconSize),
      ),
    );
  }
}

// Data class for menu items
class _MenuItemData {
  final IconData icon;
  final Color color;
  final String id;

  _MenuItemData(this.icon, this.color, this.id);
}

class DraggableChatIcon extends ConsumerStatefulWidget {
  final Offset position;
  final Function(Offset) onDragEnd;

  final String overlayMode;
  final VoidCallback onTapMain;
  final VoidCallback onOpenApp;

  const DraggableChatIcon({
    super.key,
    required this.position,
    required this.onDragEnd,
    required this.overlayMode,
    required this.onTapMain,
    required this.onOpenApp,
  });

  @override
  ConsumerState<DraggableChatIcon> createState() => _DraggableChatIconState();
}

class _DraggableChatIconState extends ConsumerState<DraggableChatIcon>
    with SingleTickerProviderStateMixin {
  late Offset _currentPosition;
  final double mainIconSize = 70.0;
  final double miniIconSize = 55.0;
  final double explosionRadius = 90.0;

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  final List<_MenuItemData> _baseMenuItems = [
    _MenuItemData(Icons.refresh, Colors.purpleAccent, 'refresh'),
    _MenuItemData(Icons.settings_suggest, Colors.purpleAccent, 'settings'),
    _MenuItemData(Icons.psychology, Colors.blueAccent, 'ai'),
    _MenuItemData(Icons.keyboard, Colors.blueAccent, 'keyboard'),
    _MenuItemData(Icons.security, Colors.blueAccent, 'security'),
  ];

  static const List<double> _rightSideAngles = [10, 40, 70, 330, 300];

  static const List<double> _leftSideAngles = [170, 200, 230, 260, 140];

  @override
  void initState() {
    super.initState();
    _currentPosition = widget.position;

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutBack,
    );

    if (widget.overlayMode == "radial") {
      _controller.value = 1.0;
    }
  }

  @override
  void didUpdateWidget(DraggableChatIcon oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.position != widget.position) {
      _currentPosition = widget.position;
    }

    if (oldWidget.overlayMode != widget.overlayMode) {
      if (widget.overlayMode == "radial") {
        _controller.forward();
      } else {
        _controller.reverse();
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  double _degToRad(double deg) => deg * (math.pi / 180.0);

  void _handleMenuAction(String id) {
    debugPrint("Tapped action: $id");

    if (id == 'ai') {
      widget.onOpenApp();
    } else {
      widget.onTapMain();
    }
  }

  Widget _buildRadialMenu(List<double> angles) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: _baseMenuItems.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;

            final angleDeg = angles[index];

            final rad = _degToRad(angleDeg - 90);
            final targetX = explosionRadius * math.cos(rad);
            final targetY = explosionRadius * math.sin(rad);

            final currentX = targetX * _fadeAnimation.value;
            final currentY = targetY * _fadeAnimation.value;

            return Positioned(
              left: (mainIconSize - miniIconSize) / 2,
              top: (mainIconSize - miniIconSize) / 2,
              child: Transform.translate(
                offset: Offset(currentX, currentY),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: GlowIconButton(
                    icon: item.icon,
                    glowColor: item.color,
                    size: miniIconSize,
                    iconSize: 24,
                    onTap: () => _handleMenuAction(item.id),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // 🛑 CRITICAL FIX: Use LayoutBuilder to access constraints immediately
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenWidth = constraints.maxWidth;
        final screenHeight = constraints.maxHeight;

        final bool isMenuOpen = widget.overlayMode == "radial";

        final centerOfIconX = _currentPosition.dx + (mainIconSize / 2);
        final isIconOnLeft = centerOfIconX < (screenWidth / 2);

        final List<double> activeAngles =
            isIconOnLeft ? _rightSideAngles : _leftSideAngles;

        return Stack(
          children: [
            if (isMenuOpen)
              Positioned.fill(
                child: GestureDetector(
                  onTap: widget.onTapMain,
                  behavior: HitTestBehavior.opaque,
                  child: Container(color: Colors.transparent),
                ),
              ),

            // We use the Positioned widget to place the icon group
            Positioned(
              left: _currentPosition.dx,
              top: _currentPosition.dy,
              child: GestureDetector(
                onPanUpdate: (details) {
                  if (isMenuOpen) {
                    widget.onTapMain();
                    return;
                  }
                  setState(() {
                    _currentPosition += details.delta;
                  });
                },
                onPanEnd: (details) {
                  if (!isMenuOpen) {
                    final topPadding = MediaQuery.of(context).padding.top;

                    final isCloserToRight = centerOfIconX > (screenWidth / 2);

                    // Keep using the fixed snap logic
                    final offsetFromEdge = explosionRadius;

                    final clampedX = isCloserToRight
                        ? (screenWidth - mainIconSize - offsetFromEdge)
                        : offsetFromEdge;
                    final clampedY = _currentPosition.dy
                        .clamp(topPadding, screenHeight - mainIconSize);

                    _currentPosition = Offset(clampedX, clampedY);
                    widget.onDragEnd(_currentPosition);
                  }
                },
                child: Stack(
                  alignment: Alignment.center,
                  clipBehavior: Clip.none,
                  children: [
                    _buildRadialMenu(activeAngles),

                    // Main Icon
                    GlowIconButton(
                      icon: Icons.local_fire_department_rounded,
                      glowColor: Colors.blueAccent,
                      size: mainIconSize,
                      iconSize: 32,
                      onTap: widget.onTapMain,
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

